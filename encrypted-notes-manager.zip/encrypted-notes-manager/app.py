#!/usr/bin/env python3
"""
Encrypted Notes Manager
Flask API yang melakukan CRUD ke MySQL dan menyimpan `content` terenkripsi
menggunakan stream XOR sederhana.
"""

import os
from flask import Flask, request, jsonify, abort, send_from_directory
import mysql.connector
from mysql.connector import Error
from datetime import datetime

app = Flask(__name__, static_folder='frontend', static_url_path='/')

# Config from env
DB_HOST = os.environ.get('DB_HOST', '127.0.0.1')
DB_PORT = int(os.environ.get('DB_PORT', '3306'))
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASS = os.environ.get('DB_PASS', '')
DB_NAME = os.environ.get('DB_NAME', 'encrypted_notes')
XOR_KEY = os.environ.get('XOR_KEY', None)

if not XOR_KEY:
    print("WARNING: XOR_KEY not set. Set environment variable XOR_KEY before running.")

def get_db_conn():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASS,
            database=DB_NAME,
            autocommit=True
        )
        return conn
    except Error as e:
        print("DB connection error:", e)
        raise

# ---- XOR stream implementation ----
def xor_stream_bytes(data: bytes, key: bytes) -> bytes:
    if not key:
        raise ValueError('Empty key')
    out = bytearray(len(data))
    klen = len(key)
    for i, b in enumerate(data):
        out[i] = b ^ key[i % klen]
    return bytes(out)

def encrypt_text(plaintext: str) -> bytes:
    pt = plaintext.encode('utf-8')
    return xor_stream_bytes(pt, XOR_KEY.encode('utf-8'))

def decrypt_bytes(ct: bytes) -> str:
    pt = xor_stream_bytes(ct, XOR_KEY.encode('utf-8'))
    return pt.decode('utf-8', errors='replace')

# ---- Routes ----
@app.route('/')
def index():
    # serve frontend static
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/notes', methods=['GET'])
def list_notes():
    conn = get_db_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute('SELECT id, title, created_at, updated_at FROM notes ORDER BY id DESC')
    rows = cur.fetchall()
    cur.close()
    conn.close()
    for r in rows:
        for k in ('created_at', 'updated_at'):
            if isinstance(r.get(k), datetime):
                r[k] = r[k].isoformat()
    return jsonify(rows)

@app.route('/notes/<int:note_id>', methods=['GET'])
def get_note(note_id):
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute('SELECT id, title, content, created_at, updated_at FROM notes WHERE id=%s', (note_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()
    if not row:
        abort(404)
    nid, title, content_blob, created_at, updated_at = row
    content_plain = ''
    if content_blob is not None:
        content_plain = decrypt_bytes(content_blob)
    return jsonify({
        'id': nid,
        'title': title,
        'content': content_plain,
        'created_at': created_at.isoformat() if isinstance(created_at, datetime) else str(created_at),
        'updated_at': updated_at.isoformat() if isinstance(updated_at, datetime) else str(updated_at),
    })

@app.route('/notes', methods=['POST'])
def create_note():
    data = request.get_json(force=True)
    title = (data.get('title') or '').strip()
    content = data.get('content') or ''
    if not title:
        return jsonify({'error': 'title required'}), 400
    ct = encrypt_text(content)
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute('INSERT INTO notes (title, content) VALUES (%s, %s)', (title, ct))
    nid = cur.lastrowid
    cur.close()
    conn.close()
    return jsonify({'id': nid}), 201

@app.route('/notes/<int:note_id>', methods=['PUT', 'PATCH'])
def update_note(note_id):
    data = request.get_json(force=True)
    title = data.get('title')
    content = data.get('content')
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute('SELECT id FROM notes WHERE id=%s', (note_id,))
    if not cur.fetchone():
        cur.close(); conn.close(); abort(404)
    if title is not None and content is not None:
        ct = encrypt_text(content)
        cur.execute('UPDATE notes SET title=%s, content=%s WHERE id=%s', (title, ct, note_id))
    elif title is not None:
        cur.execute('UPDATE notes SET title=%s WHERE id=%s', (title, note_id))
    elif content is not None:
        ct = encrypt_text(content)
        cur.execute('UPDATE notes SET content=%s WHERE id=%s', (ct, note_id))
    cur.close()
    conn.close()
    return jsonify({'ok': True})

@app.route('/notes/<int:note_id>', methods=['DELETE'])
def delete_note(note_id):
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute('DELETE FROM notes WHERE id=%s', (note_id,))
    affected = cur.rowcount
    cur.close()
    conn.close()
    if affected == 0:
        abort(404)
    return jsonify({'ok': True})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

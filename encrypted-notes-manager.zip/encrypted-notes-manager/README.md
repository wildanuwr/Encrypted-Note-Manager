# Encrypted Notes Manager

A simple demo app that performs CRUD operations on a MySQL database while encrypting the `content` field using a simple Stream XOR cipher. This is an educational project — **do not** use this cipher in production.

## Features
- Create, Read, Update, Delete notes
- Content encrypted with XOR stream before stored in DB
- Simple web frontend for demo (optional)

## Requirements
- Python 3.8+
- MySQL / MariaDB

## Setup
1. Create database and table:
   ```bash
   mysql -u root -p < sql/dump_notes.sql
   ```
2. Create virtualenv and install deps:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\\Scripts\\activate
   pip install -r requirements.txt
   ```
3. Export environment variables:
   ```bash
   export DB_HOST=127.0.0.1
   export DB_PORT=3306
   export DB_USER=root
   export DB_PASS=yourpassword
   export DB_NAME=encrypted_notes
   export XOR_KEY="kunci_rahasia_panjang"
   ```
4. Run app:
   ```bash
   python app.py
   ```
5. Open `http://127.0.0.1:5000/` to use the demo frontend, or use curl / Postman to call the API.

## API Endpoints
- `GET /notes` — list notes (metadata)
- `GET /notes/<id>` — get and decrypt note content
- `POST /notes` — create note `{title, content}`
- `PUT /notes/<id>` — update (title and/or content)
- `DELETE /notes/<id>` — delete

## Security notes
- XOR stream in this repo is intentionally simple for teaching. Weaknesses:
  - Reusing key leaks info
  - No authentication / no integrity checks
  - Key length matters
- For real systems, use AES-GCM or other authenticated encryption.
